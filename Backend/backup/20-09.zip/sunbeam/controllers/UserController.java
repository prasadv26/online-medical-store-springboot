package com.sunbeam.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.common.CustomResponse;
import com.sunbeam.dtos.UserDto;
import com.sunbeam.entities.User;
import com.sunbeam.services.UserService;

@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/user")
@RestController
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private CustomResponse response;

	@PostMapping("/login")
	public CustomResponse login(@RequestParam String email, @RequestParam String password) {
		User user = null;
		try {
			user = service.authenticate(email, password);
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("error");
		}
		if (user == null) {
			response.setStatus("error");
			response.setData("");
		} else {
			response.setStatus("success");
			response.setData(user);
		}
		return response;
	}

	@PostMapping("/addUser")
	public CustomResponse signup( @RequestBody User user) {

		User user1 = null;

		try {
			user1 = service.save(user);

		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("error");
		}
		if (user1 == null) {
			response.setStatus("error");
			response.setData("");
		} else {
			response.setStatus("success");
			response.setData(user1);
		}

		return response;
	}

	@GetMapping("/getUser/{id}")
	public CustomResponse getUser(@PathVariable("id") int id) {

		User user = null;
		UserDto userdto = null;
		try {
			user = service.findById(id);
			userdto = UserDto.fromEntity(user);
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("error");
		}

		response.setStatus("success");
		response.setData(userdto);
		return response;

	}

	@GetMapping("/getAllUsers")
	public CustomResponse getAllUsers() {

		List<User> list = new ArrayList<User>();

		try {
			list = service.findAllUser();
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("error");
		}

		response.setStatus("success");
		response.setData(list);
		return response;
	}

	@PutMapping("/updateUser")
	public CustomResponse updateUser(int id, User user) {
		User user1 = null;
		try {
			user1 = service.update(id, user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (user1 == null) {
			response.setStatus("error");
			response.setData("");
		} else {
			response.setStatus("success");
			response.setData(user1);
		}
		return response;
	}

	@PutMapping("/changePassword")
	public CustomResponse changePassword(@RequestParam String password, @RequestParam String email) {
		try {
			service.userPassword(password, email);
			System.out.println("changed successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.setStatus("success");
		response.setData("Password Changed Successfully!!!!!");
		return response;
	}
}
